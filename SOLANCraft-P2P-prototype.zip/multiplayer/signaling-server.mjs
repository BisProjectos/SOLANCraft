// Minimal WebSocket signaling relay for SOLANCraft WebRTC multiplayer.
// Install: npm install ws
// Run: node signaling-server.mjs
import { WebSocketServer, WebSocket } from 'ws';

const port = Number(process.env.PORT || 8787);
const wss = new WebSocketServer({ port });
const rooms = new Map();

function send(ws, message) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message));
}
function leave(ws) {
  const room = ws.room;
  if (!room) return;
  const peers = rooms.get(room);
  if (peers) {
    peers.delete(ws);
    for (const peer of peers) send(peer, { type: 'peer-left' });
    if (!peers.size) rooms.delete(room);
  }
  ws.room = null;
}
wss.on('connection', ws => {
  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch (_) { return; }
    if (m.type === 'join-room') {
      const room = String(m.room || '').trim().slice(0, 80);
      if (!room) return send(ws, { type: 'room-error', message: 'Room code required.' });
      leave(ws);
      let peers = rooms.get(room);
      if (!peers) { peers = new Set(); rooms.set(room, peers); }
      if (peers.size >= 2) return send(ws, { type: 'room-error', message: 'Room is full (two players maximum).' });
      ws.room = room;
      ws.role = m.role === 'host' ? 'host' : 'join';
      peers.add(ws);
      if (peers.size === 2) {
        // The host always creates the WebRTC offer, regardless of connection order.
        for (const peer of peers) {
          if (peer.role === 'host') send(peer, { type: 'peer-joined' });
        }
      }
      return;
    }
    if (m.type === 'signal' && ws.room) {
      const peers = rooms.get(ws.room);
      if (!peers) return;
      for (const peer of peers) {
        if (peer !== ws) send(peer, { type: 'signal', from: m.from, payload: m.payload });
      }
    }
  });
  ws.on('close', () => leave(ws));
  ws.on('error', () => leave(ws));
});
wss.on('listening', () => console.log(`SOLANCraft signaling server listening on ws://0.0.0.0:${port}`));
