// Run from the SOLANCraft repository root:
//   node multiplayer/apply-patch.mjs
// It copies the multiplayer script into src and inserts it into src/ORDER.txt once.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.cwd();
const here = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(here, '..', 'src', 'multiplayer', 'p2p.js');
const targetDir = path.join(root, 'src', 'multiplayer');
const target = path.join(targetDir, 'p2p.js');
const orderPath = path.join(root, 'src', 'ORDER.txt');
if (!fs.existsSync(orderPath)) {
  console.error('Run this script from the SOLANCraft repository root (src/ORDER.txt was not found).');
  process.exit(1);
}
fs.mkdirSync(targetDir, { recursive: true });
if (path.resolve(source) !== path.resolve(target)) fs.copyFileSync(source, target);
let order = fs.readFileSync(orderPath, 'utf8');
const entry = 'multiplayer/p2p.js';
if (!order.split(/\r?\n/).includes(entry)) {
  const marker = 'boot/export_boot.js';
  if (!order.includes(marker)) {
    console.error('Could not find boot/export_boot.js in src/ORDER.txt; no order changes made.');
    process.exit(1);
  }
  order = order.replace(marker, '# Peer-to-peer multiplayer bridge\n' + entry + '\n\n' + marker);
  fs.writeFileSync(orderPath, order);
  console.log('Inserted multiplayer/p2p.js into src/ORDER.txt.');
} else {
  console.log('src/ORDER.txt already includes multiplayer/p2p.js.');
}
console.log('Copied src/multiplayer/p2p.js. Now run: node scripts/build.mjs');
