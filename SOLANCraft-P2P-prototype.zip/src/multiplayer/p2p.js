/* SOLANCraft peer-to-peer multiplayer bridge.
 * Loaded as a classic script after the game engine parts.
 * Connect in DevTools: SOLANCraftMP.host("ROOMCODE") / SOLANCraftMP.join("ROOMCODE")
 * Configure signaling URL with SOLANCraftMP.setSignalingUrl(url) before host/join.
 */
(function () {
  'use strict';

  const MP = {
    version: 1,
    signalingUrl: 'ws://localhost:8787',
    role: null,
    room: null,
    ws: null,
    pc: null,
    dc: null,
    peerId: null,
    localId: Math.random().toString(36).slice(2, 10),
    connected: false,
    applyingRemote: false,
    remoteMesh: null,
    remoteTarget: null,
    tick: null,
    lastPoseSent: 0,
    started: false,
    lastWorldSync: false
  };

  function log(...args) { console.info('[SOLANCraftMP]', ...args); }
  function status() {
    return {
      role: MP.role, room: MP.room, connected: MP.connected,
      signaling: MP.ws ? MP.ws.readyState : 'closed',
      dataChannel: MP.dc ? MP.dc.readyState : 'closed'
    };
  }
  function send(obj) {
    if (MP.dc && MP.dc.readyState === 'open') {
      try { MP.dc.send(JSON.stringify(obj)); return true; } catch (e) { log('send failed', e); }
    }
    return false;
  }
  function signal(obj) {
    if (MP.ws && MP.ws.readyState === WebSocket.OPEN) {
      MP.ws.send(JSON.stringify(Object.assign({ room: MP.room, from: MP.localId }, obj)));
    }
  }
  function connectSignaling() {
    if (!MP.room) throw new Error('Room code required.');
    if (MP.ws && (MP.ws.readyState === WebSocket.OPEN || MP.ws.readyState === WebSocket.CONNECTING)) {
      MP.ws.close();
    }
    const ws = new WebSocket(MP.signalingUrl);
    MP.ws = ws;
    ws.addEventListener('open', () => {
      signal({ type: 'join-room', role: MP.role });
      log('signaling connected; waiting for the other player in room', MP.room);
    });
    ws.addEventListener('message', async ev => {
      let m;
      try { m = JSON.parse(ev.data); } catch (_) { return; }
      try {
        if (m.type === 'peer-joined' && MP.role === 'host') await createOffer();
        else if (m.type === 'signal' && m.from !== MP.localId) await onSignal(m.payload);
        else if (m.type === 'peer-left') { MP.connected = false; removeRemoteMesh(); log('peer disconnected'); }
        else if (m.type === 'room-error') log('signaling error:', m.message);
      } catch (e) { console.error('[SOLANCraftMP] signaling handler error', e); }
    });
    ws.addEventListener('close', () => log('signaling socket closed'));
    ws.addEventListener('error', () => log('Could not reach signaling server:', MP.signalingUrl));
  }
  function relay(payload) { signal({ type: 'signal', payload }); }

  function makePeer() {
    if (MP.pc) MP.pc.close();
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' }
      ]
    });
    MP.pc = pc;
    pc.onicecandidate = e => { if (e.candidate) relay({ kind: 'ice', candidate: e.candidate }); };
    pc.onconnectionstatechange = () => {
      log('peer connection:', pc.connectionState);
      if (pc.connectionState === 'failed') {
        log('Direct connection failed. A TURN relay may be required for this network.');
      }
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'closed' || pc.connectionState === 'failed') {
        MP.connected = false;
      }
    };
    pc.ondatachannel = e => setupDataChannel(e.channel);
    return pc;
  }
  async function createOffer() {
    if (MP.pc) return;
    const pc = makePeer();
    setupDataChannel(pc.createDataChannel('solancraft-world', { ordered: true }));
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    relay({ kind: 'description', description: pc.localDescription });
  }
  async function onSignal(payload) {
    if (!payload) return;
    if (payload.kind === 'description') {
      if (!MP.pc) makePeer();
      if (payload.description.type === 'offer') {
        await MP.pc.setRemoteDescription(payload.description);
        const answer = await MP.pc.createAnswer();
        await MP.pc.setLocalDescription(answer);
        relay({ kind: 'description', description: MP.pc.localDescription });
      } else {
        await MP.pc.setRemoteDescription(payload.description);
      }
    } else if (payload.kind === 'ice' && MP.pc) {
      try { await MP.pc.addIceCandidate(payload.candidate); }
      catch (e) { log('ICE candidate rejected', e); }
    }
  }
  function setupDataChannel(dc) {
    MP.dc = dc;
    dc.onopen = () => {
      MP.connected = true;
      log('P2P connected. Role:', MP.role, 'room:', MP.room);
      if (MP.role === 'host') sendWorldSnapshot();
      else send({ type: 'hello', version: MP.version, id: MP.localId });
      startPoseTicker();
    };
    dc.onclose = () => { MP.connected = false; log('data channel closed'); };
    dc.onerror = e => console.warn('[SOLANCraftMP] data channel error', e);
    dc.onmessage = ev => {
      try { handlePacket(JSON.parse(ev.data)); }
      catch (e) { console.warn('[SOLANCraftMP] bad packet', e); }
    };
  }

  function handlePacket(m) {
    if (!m || typeof m.type !== 'string') return;
    if (m.type === 'hello') {
      if (m.version !== MP.version) { log('Peer version mismatch; use matching source versions.'); return; }
      MP.peerId = m.id;
      return;
    }
    if (m.type === 'world-meta') {
      if (MP.role !== 'join') return;
      // The joining player adopts the host's seed. This deliberately starts a fresh
      // local session; unsaved edits in the joining player's previous world are not kept.
      if (typeof m.seed !== 'number') return;
      if (typeof startNewWorld === 'function') {
        try {
          MP.applyingRemote = true;
          startNewWorld('Multiplayer - ' + MP.room, String(m.seed), (m.mode === 'c' ? 'c' : 's'), false);
        } finally { MP.applyingRemote = false; }
      } else if (typeof SEED !== 'undefined') {
        SEED = m.seed;
      }
      MP.lastWorldSync = true;
      send({ type: 'world-meta-ack', seed: m.seed });
      return;
    }
    if (m.type === 'world-meta-ack') {
      if (MP.role === 'host') log('Peer acknowledged world seed', m.seed);
      return;
    }
    if (m.type === 'world-edit') {
      applyWorldEdit(m.x, m.y, m.z, m.id);
      return;
    }
    if (m.type === 'world-batch') {
      if (Array.isArray(m.edits)) {
        for (const e of m.edits) applyWorldEdit(e.x, e.y, e.z, e.id);
      }
      return;
    }
    if (m.type === 'world-sync-done') {
      log('Initial block-edit sync complete.');
      return;
    }
    if (m.type === 'pose') {
      if (typeof m.x !== 'number' || typeof m.y !== 'number' || typeof m.z !== 'number') return;
      MP.remoteTarget = m;
      updateRemoteMesh();
      return;
    }
  }

  function applyWorldEdit(x, y, z, id) {
    if (![x, y, z, id].every(Number.isFinite) || typeof setBlock !== 'function') return;
    try {
      MP.applyingRemote = true;
      // setBlock only changes loaded chunks. Ensure the target chunk exists first.
      if (typeof chunkAt === 'function' && typeof createChunk === 'function' && !chunkAt(x, z)) {
        createChunk(Math.floor(x / CH), Math.floor(z / CH));
      }
      setBlock(Math.floor(x), Math.floor(y), Math.floor(z), id);
    } catch (e) { console.warn('[SOLANCraftMP] failed to apply block edit', e); }
    finally { MP.applyingRemote = false; }
  }

  function sendWorldSnapshot() {
    if (typeof SEED !== 'number') { log('Cannot sync world: seed unavailable.'); return; }
    send({ type: 'world-meta', seed: SEED, mode: (typeof P !== 'undefined' && P.mode === 'c') ? 'c' : 's' });
    const batch = [];
    // chunkEdits contains player/world edits persisted by SOLANCraft's chunk store.
    if (typeof chunkEdits !== 'undefined') {
      for (const [ck, edits] of chunkEdits) {
        const parts = ck.split(',').map(Number);
        if (parts.length !== 2 || !edits) continue;
        for (const [localKey, id] of edits) {
          const p = localKey.split(',').map(Number);
          if (p.length !== 3 || !p.every(Number.isFinite)) continue;
          batch.push({ x: parts[0] * CH + p[0], y: p[1], z: parts[1] * CH + p[2], id });
          if (batch.length >= 100) {
            send({ type: 'world-batch', edits: batch.splice(0, batch.length) });
          }
        }
      }
    }
    if (batch.length) send({ type: 'world-batch', edits: batch });
    send({ type: 'world-sync-done' });
    log('Sent initial block edits.');
  }

  function installWorldHook() {
    if (MP.worldHookInstalled || typeof setBlock !== 'function') return;
    const original = setBlock;
    setBlock = function (x, y, z, id) {
      const before = (typeof getBlock === 'function') ? getBlock(x, y, z) : undefined;
      const result = original.apply(this, arguments);
      if (!MP.applyingRemote && MP.connected && before !== id) {
        send({ type: 'world-edit', x: Math.floor(x), y: Math.floor(y), z: Math.floor(z), id });
      }
      return result;
    };
    MP.worldHookInstalled = true;
  }

  function ensureRemoteMesh() {
    if (MP.remoteMesh || typeof THREE === 'undefined' || !scene) return;
    const group = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(0.62, 1.75, 0.42),
      new THREE.MeshLambertMaterial({ color: 0x46b5ff })
    );
    body.position.y = 0.88;
    group.add(body);
    const head = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.5, 0.5),
      new THREE.MeshLambertMaterial({ color: 0xffd0a0 })
    );
    head.position.y = 2.0;
    group.add(head);
    group.userData.solancraftRemotePlayer = true;
    scene.add(group);
    MP.remoteMesh = group;
  }
  function updateRemoteMesh() {
    if (!MP.remoteTarget) return;
    ensureRemoteMesh();
    if (!MP.remoteMesh) return;
    const p = MP.remoteTarget;
    MP.remoteMesh.position.set(p.x, p.y, p.z);
    MP.remoteMesh.rotation.y = Number.isFinite(p.yaw) ? p.yaw : 0;
    MP.remoteMesh.visible = true;
  }
  function removeRemoteMesh() {
    if (MP.remoteMesh && scene) {
      scene.remove(MP.remoteMesh);
      MP.remoteMesh.traverse(o => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
          else o.material.dispose();
        }
      });
    }
    MP.remoteMesh = null;
    MP.remoteTarget = null;
  }
  function startPoseTicker() {
    if (MP.tick) return;
    MP.tick = setInterval(() => {
      installWorldHook();
      if (!MP.connected || !MP.dc || MP.dc.readyState !== 'open' ||
          typeof P === 'undefined' || !P || typeof playing !== 'undefined' && !playing) return;
      const now = performance.now();
      if (now - MP.lastPoseSent < 50) return;
      MP.lastPoseSent = now;
      send({
        type: 'pose', x: +P.x.toFixed(3), y: +P.y.toFixed(3), z: +P.z.toFixed(3),
        yaw: +P.yaw.toFixed(3), pitch: +P.pitch.toFixed(3),
        mode: P.mode || 's', hp: Number.isFinite(P.hp) ? P.hp : 20
      });
    }, 25);
  }

  MP.setSignalingUrl = function (url) {
    if (MP.ws) MP.ws.close();
    MP.signalingUrl = String(url);
    return status();
  };
  MP.host = function (room) {
    disconnect();
    MP.role = 'host'; MP.room = String(room || '').trim();
    connectSignaling();
    return 'Hosting room ' + MP.room + '. Have the other player run SOLANCraftMP.join(' + JSON.stringify(MP.room) + ').';
  };
  MP.join = function (room) {
    disconnect();
    MP.role = 'join'; MP.room = String(room || '').trim();
    connectSignaling();
    return 'Joining room ' + MP.room + '.';
  };
  function disconnect() {
    MP.connected = false;
    if (MP.tick) { clearInterval(MP.tick); MP.tick = null; }
    if (MP.dc) { try { MP.dc.close(); } catch (_) {} MP.dc = null; }
    if (MP.pc) { try { MP.pc.close(); } catch (_) {} MP.pc = null; }
    if (MP.ws) { try { MP.ws.close(); } catch (_) {} MP.ws = null; }
    removeRemoteMesh();
  }
  MP.disconnect = disconnect;
  MP.status = status;
  MP.sendWorldSnapshot = sendWorldSnapshot;
  MP._installWorldHook = installWorldHook;

  // Install once now, then again on a timer in case another source part wraps setBlock later.
  installWorldHook();
  window.SOLANCraftMP = MP;
  log('loaded. Use SOLANCraftMP.host("ROOMCODE") or SOLANCraftMP.join("ROOMCODE") in DevTools.');
})();
