# SOLANCraft P2P multiplayer prototype

This adds a minimal two-player WebRTC connection to SOLANCraft, with:
- player position / yaw / pitch synchronization;
- synchronization of block edits made after connecting;
- an initial transfer of saved block edits from the host;
- a minimal remote-player placeholder mesh;
- a small WebSocket signaling relay.

## Important limitations

This is a prototype, not yet a complete Minecraft multiplayer implementation. It does **not** yet synchronize inventory, health changes, mobs, dropped items, vehicles, crafting, doors' side effects, time-of-day, or dimension transitions. Host and joiner should use the same SOLANCraft source version. The host's seed is applied to the joining session, which starts a fresh local session; do not join while relying on unsaved changes in the joining player's existing world.

The WebRTC configuration uses a public STUN server but no TURN server. Direct connections may fail on some NAT/firewall configurations; in that case configure a TURN service in `src/multiplayer/p2p.js`.

The signaling server is not an authoritative game server. Do not expose it publicly without adding authentication, room-code protections/rate limits, TLS (`wss://`), and operational safeguards. Anyone who knows a room code can attempt to join it.

## Install into the game

1. Unzip these files into the root of your SOLANCraft clone, merging folders.
2. Open a terminal in the repository root and run:
   ```sh
   node multiplayer/apply-patch.mjs
   node scripts/build.mjs
   ```
3. Open the generated `dist/` game in two browser windows.

## Start signaling

In a terminal:
```sh
cd multiplayer
npm install
npm start
```
The default signaling address is `ws://localhost:8787`. This is enough only when both browser windows are on the same computer. For two different computers, host the signaling relay on a reachable server and use its `wss://` URL (TLS recommended). The game peers then attempt to send gameplay directly over WebRTC.

## Connect the two players

Open browser DevTools → Console in both windows. Start a world in each window first. In Player 1's console:
```js
SOLANCraftMP.host("test-room-42")
```
In Player 2's console:
```js
SOLANCraftMP.join("test-room-42")
```
The joiner's session is reset to the host's seed when the world metadata arrives. The first connection transfers the host's block edits, then both sides send position updates and relay subsequent block edits.

Useful console commands:
```js
SOLANCraftMP.status()
SOLANCraftMP.disconnect()
SOLANCraftMP.sendWorldSnapshot() // host can manually resend block edits
SOLANCraftMP.setSignalingUrl("wss://your-signaling-host.example")
```

## Test checklist

- Both windows use the same source/build.
- Both started a world before connecting.
- `SOLANCraftMP.status()` reports `connected: true`.
- Walk in either window and confirm the blue placeholder player moves.
- Break/place a block after connection and confirm it appears in the other window.
- Refreshing/reconnecting is not yet a durable session-resume workflow; start with a fresh world if testing state mismatches.
